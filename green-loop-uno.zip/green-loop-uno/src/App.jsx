import React, { useEffect, useState } from "react";
import { auth, ensureSignedIn } from "./firebase";
import Lobby from "./components/Lobby.jsx";
import GameRoom from "./components/GameRoom.jsx";

export default function App() {
  const [uid, setUid] = useState(null);
  const [ready, setReady] = useState(false);
  const [roomCode, setRoomCode] = useState(null);
  const [playerName, setPlayerName] = useState("");

  useEffect(() => {
    ensureSignedIn().then((user) => {
      setUid(user.uid);
      setReady(true);
    });
  }, []);

  if (!ready) {
    return (
      <div className="center-screen">
        <p>연결 중...</p>
      </div>
    );
  }

  if (!roomCode) {
    return (
      <Lobby
        uid={uid}
        onEnterRoom={(code, name) => {
          setPlayerName(name);
          setRoomCode(code);
        }}
      />
    );
  }

  return (
    <GameRoom
      uid={uid}
      roomCode={roomCode}
      playerName={playerName}
      onLeave={() => setRoomCode(null)}
    />
  );
}
