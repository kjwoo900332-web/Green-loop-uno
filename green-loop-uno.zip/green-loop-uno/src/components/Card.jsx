import React from "react";
import { COLOR_HEX, CARD_LABEL } from "../gameLogic";

export default function Card({ card, onClick, disabled, faceDown, small }) {
  if (faceDown) {
    return (
      <div className={`card facedown ${small ? "small" : ""}`}>
        <span>🌍</span>
      </div>
    );
  }

  const bg = COLOR_HEX[card.color] || "#333";
  const label =
    card.type === "number" ? card.value : CARD_LABEL[card.type] || card.type;

  return (
    <button
      className={`card ${small ? "small" : ""} ${disabled ? "disabled" : ""}`}
      style={{ background: bg }}
      onClick={() => !disabled && onClick && onClick(card)}
      disabled={disabled}
    >
      <span className="card-label">{label}</span>
    </button>
  );
}
