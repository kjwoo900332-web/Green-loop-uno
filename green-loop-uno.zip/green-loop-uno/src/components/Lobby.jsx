import React, { useState } from "react";
import {
  db,
  doc,
  setDoc,
  getDoc,
  serverTimestamp
} from "../firebase";
import { runTransaction, collection } from "firebase/firestore";
import { makeInviteCode } from "../gameLogic";

const MAX_PLAYERS = 6;

export default function Lobby({ uid, onEnterRoom }) {
  const [name, setName] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [mode, setMode] = useState("menu"); // menu | create | join
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleCreate() {
    if (!name.trim()) {
      setError("이름을 입력해주세요.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      let code = makeInviteCode();
      // 코드 중복 방지 (희박하지만 체크)
      let existing = await getDoc(doc(db, "rooms", code));
      let tries = 0;
      while (existing.exists() && tries < 5) {
        code = makeInviteCode();
        existing = await getDoc(doc(db, "rooms", code));
        tries++;
      }

      await setDoc(doc(db, "rooms", code), {
        hostUid: uid,
        status: "waiting",
        direction: 1,
        turnOrder: [uid],
        currentTurnUid: null,
        currentColor: null,
        deck: [],
        discardPile: [],
        drawPenalty: 0,
        winnerUid: null,
        createdAt: serverTimestamp()
      });

      await setDoc(doc(db, "rooms", code, "players", uid), {
        name: name.trim(),
        isHost: true,
        handCount: 0,
        netZero: false,
        joinedAt: serverTimestamp()
      });
      await setDoc(doc(db, "rooms", code, "hands", uid), { cards: [] });

      onEnterRoom(code, name.trim());
    } catch (e) {
      console.error(e);
      setError("방 생성에 실패했어요. 다시 시도해주세요.");
    } finally {
      setLoading(false);
    }
  }

  async function handleJoin() {
    if (!name.trim()) {
      setError("이름을 입력해주세요.");
      return;
    }
    const code = joinCode.trim().toUpperCase();
    if (code.length < 4) {
      setError("초대 코드를 확인해주세요.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const roomRef = doc(db, "rooms", code);

      await runTransaction(db, async (tx) => {
        const roomSnap = await tx.get(roomRef);
        if (!roomSnap.exists()) {
          throw new Error("방을 찾을 수 없어요. 코드를 다시 확인해주세요.");
        }
        const room = roomSnap.data();
        if (room.status !== "waiting") {
          throw new Error("이미 게임이 시작된 방이에요.");
        }
        if (room.turnOrder.includes(uid)) {
          return; // 이미 참가중 - 재입장
        }
        if (room.turnOrder.length >= MAX_PLAYERS) {
          throw new Error("방이 가득 찼어요 (최대 6명).");
        }
        tx.update(roomRef, {
          turnOrder: [...room.turnOrder, uid]
        });
        const playerRef = doc(db, "rooms", code, "players", uid);
        tx.set(playerRef, {
          name: name.trim(),
          isHost: false,
          handCount: 0,
          netZero: false,
          joinedAt: serverTimestamp()
        });
        const handRef = doc(db, "rooms", code, "hands", uid);
        tx.set(handRef, { cards: [] });
      });

      onEnterRoom(code, name.trim());
    } catch (e) {
      console.error(e);
      setError(e.message || "입장에 실패했어요.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="lobby">
      <h1>🌱 Green Loop</h1>
      <p className="subtitle">SDGs UNO — 재생지로 만든 순환 카드게임</p>

      {mode === "menu" && (
        <div className="menu-buttons">
          <button className="primary" onClick={() => setMode("create")}>
            방 만들기
          </button>
          <button className="secondary" onClick={() => setMode("join")}>
            초대 코드로 입장
          </button>
        </div>
      )}

      {mode !== "menu" && (
        <div className="form">
          <label>이름</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="닉네임 입력"
            maxLength={10}
          />

          {mode === "join" && (
            <>
              <label>초대 코드</label>
              <input
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                placeholder="예: A3F9K2"
                maxLength={6}
              />
            </>
          )}

          {error && <p className="error">{error}</p>}

          <div className="form-actions">
            <button
              className="primary"
              disabled={loading}
              onClick={mode === "create" ? handleCreate : handleJoin}
            >
              {loading ? "처리 중..." : mode === "create" ? "방 만들기" : "입장하기"}
            </button>
            <button className="link" onClick={() => setMode("menu")}>
              뒤로
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
