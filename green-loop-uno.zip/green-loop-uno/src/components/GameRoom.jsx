import React, { useEffect, useState, useMemo } from "react";
import {
  db,
  doc,
  onSnapshot,
  updateDoc
} from "../firebase";
import {
  collection,
  runTransaction
} from "firebase/firestore";
import {
  createDeck,
  canPlay,
  nextPlayerIndex,
  COLORS,
  COLOR_LABEL,
  COLOR_HEX
} from "../gameLogic";
import Card from "./Card.jsx";
import WinScreen from "./WinScreen.jsx";

const MAX_PLAYERS = 6;

export default function GameRoom({ uid, roomCode, playerName, onLeave }) {
  const [room, setRoom] = useState(null);
  const [players, setPlayers] = useState([]);
  const [myHand, setMyHand] = useState([]);
  const [pendingWild, setPendingWild] = useState(null); // wild 카드 낼 때 색 선택 대기
  const [error, setError] = useState("");

  const roomRef = useMemo(() => doc(db, "rooms", roomCode), [roomCode]);
  const myHandRef = useMemo(
    () => doc(db, "rooms", roomCode, "hands", uid),
    [roomCode, uid]
  );

  useEffect(() => {
    const unsub = onSnapshot(roomRef, (snap) => {
      if (snap.exists()) setRoom({ id: snap.id, ...snap.data() });
    });
    return unsub;
  }, [roomRef]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "rooms", roomCode, "players"), (snap) => {
      const list = [];
      snap.forEach((d) => list.push({ uid: d.id, ...d.data() }));
      setPlayers(list);
    });
    return unsub;
  }, [roomCode]);

  useEffect(() => {
    const unsub = onSnapshot(myHandRef, (snap) => {
      if (snap.exists()) setMyHand(snap.data().cards || []);
    });
    return unsub;
  }, [myHandRef]);

  if (!room) {
    return (
      <div className="center-screen">
        <p>방 정보를 불러오는 중...</p>
      </div>
    );
  }

  const orderedPlayers = room.turnOrder
    .map((pid) => players.find((p) => p.uid === pid))
    .filter(Boolean);

  const topCard = room.discardPile?.[room.discardPile.length - 1] || null;
  const isMyTurn = room.currentTurnUid === uid;
  const me = players.find((p) => p.uid === uid);

  // ---- 방장: 게임 시작 ----
  async function startGame() {
    setError("");
    try {
      await runTransaction(db, async (tx) => {
        const roomSnap = await tx.get(roomRef);
        const roomData = roomSnap.data();
        const order = roomData.turnOrder;
        if (order.length < 2) throw new Error("최소 2명이 있어야 시작할 수 있어요.");

        let deck = createDeck();
        const hands = {};
        order.forEach((pid) => {
          hands[pid] = deck.splice(0, 7);
        });

        let starter = deck.shift();
        // 첫 카드가 탄소폭탄이면 다음 카드와 교체
        while (starter.type === "wild4") {
          deck.push(starter);
          starter = deck.shift();
        }
        const startColor = starter.color === "wild" ? "green" : starter.color;

        // 핸드 문서들 미리 읽어야 하므로 ref 준비 (쓰기는 트랜잭션 밖에서도 되지만 일관성 위해 개별 update)
        order.forEach((pid) => {
          const handRef = doc(db, "rooms", roomCode, "hands", pid);
          tx.update(handRef, { cards: hands[pid] });
          const playerRef = doc(db, "rooms", roomCode, "players", pid);
          tx.update(playerRef, { handCount: hands[pid].length, netZero: false });
        });

        tx.update(roomRef, {
          status: "playing",
          deck,
          discardPile: [starter],
          currentColor: startColor,
          currentTurnUid: order[0],
          direction: 1,
          winnerUid: null
        });
      });
    } catch (e) {
      console.error(e);
      setError(e.message || "게임 시작에 실패했어요.");
    }
  }

  // ---- 카드 내기 ----
  async function handlePlay(card) {
    if (!isMyTurn) return;
    if (!canPlay(card, topCard, room.currentColor)) {
      setError("지금은 낼 수 없는 카드예요.");
      return;
    }
    if (card.color === "wild") {
      setPendingWild(card);
      return;
    }
    await doPlay(card, null);
  }

  async function doPlay(card, chosenColor) {
    setError("");
    setPendingWild(null);
    try {
      await runTransaction(db, async (tx) => {
        const roomSnap = await tx.get(roomRef);
        const handSnap = await tx.get(myHandRef);
        const roomData = roomSnap.data();
        const handData = handSnap.data();

        const cards = handData.cards.filter((c) => c.id !== card.id);
        if (cards.length === handData.cards.length) {
          throw new Error("카드를 찾을 수 없어요.");
        }

        const turnOrder = roomData.turnOrder;
        const curIdx = turnOrder.indexOf(uid);
        let direction = roomData.direction;
        let skipCount = 1;
        let drawTargetIdx = null;
        let drawAmount = 0;
        let extraTurn = false;

        switch (card.type) {
          case "skip":
            skipCount = 2;
            break;
          case "reverse":
            direction = direction * -1;
            skipCount = turnOrder.length === 2 ? 2 : 1;
            break;
          case "draw2":
            drawTargetIdx = nextPlayerIndex(curIdx, turnOrder.length, direction, 1);
            drawAmount = 2;
            skipCount = 2;
            break;
          case "wild4":
            drawTargetIdx = nextPlayerIndex(curIdx, turnOrder.length, direction, 1);
            drawAmount = 4;
            skipCount = 2;
            break;
          case "greenaction":
            extraTurn = true;
            skipCount = 0;
            break;
          default:
            skipCount = 1;
        }

        let deck = [...roomData.deck];
        let targetHandRef = null;
        let targetHandSnap = null;
        let targetUid = null;
        if (drawTargetIdx !== null) {
          targetUid = turnOrder[drawTargetIdx];
          targetHandRef = doc(db, "rooms", roomCode, "hands", targetUid);
          targetHandSnap = await tx.get(targetHandRef);
        }

        let drawnCards = [];
        if (drawAmount > 0) {
          drawnCards = deck.splice(0, Math.min(drawAmount, deck.length));
        }

        const newDiscard = [...roomData.discardPile, card];
        const newColor = card.color === "wild" ? chosenColor : card.color;
        const iWon = cards.length === 0;

        const nextIdx = extraTurn
          ? curIdx
          : nextPlayerIndex(curIdx, turnOrder.length, direction, skipCount);
        const nextUid = turnOrder[nextIdx];

        tx.update(roomRef, {
          deck,
          discardPile: newDiscard,
          currentColor: newColor,
          direction,
          currentTurnUid: iWon ? null : nextUid,
          status: iWon ? "finished" : "playing",
          winnerUid: iWon ? uid : null
        });

        tx.update(myHandRef, { cards });
        tx.update(doc(db, "rooms", roomCode, "players", uid), {
          handCount: cards.length,
          netZero: cards.length === 1 ? me?.netZeroPending || false : false
        });

        if (targetHandRef && targetHandSnap) {
          const targetCards = [...(targetHandSnap.data().cards || []), ...drawnCards];
          tx.update(targetHandRef, { cards: targetCards });
          tx.update(doc(db, "rooms", roomCode, "players", targetUid), {
            handCount: targetCards.length
          });
        }
      });
    } catch (e) {
      console.error(e);
      setError(e.message || "카드를 내지 못했어요.");
    }
  }

  // ---- 카드 뽑기 (낼 카드 없을 때) ----
  async function handleDraw() {
    if (!isMyTurn) return;
    setError("");
    try {
      await runTransaction(db, async (tx) => {
        const roomSnap = await tx.get(roomRef);
        const handSnap = await tx.get(myHandRef);
        const roomData = roomSnap.data();
        const handData = handSnap.data();

        let deck = [...roomData.deck];
        if (deck.length === 0) {
          throw new Error("남은 카드가 없어요.");
        }
        const drawn = deck.splice(0, 1);
        const newCards = [...handData.cards, ...drawn];

        const turnOrder = roomData.turnOrder;
        const curIdx = turnOrder.indexOf(uid);
        const nextIdx = nextPlayerIndex(curIdx, turnOrder.length, roomData.direction, 1);
        const nextUid = turnOrder[nextIdx];

        tx.update(roomRef, { deck, currentTurnUid: nextUid });
        tx.update(myHandRef, { cards: newCards });
        tx.update(doc(db, "rooms", roomCode, "players", uid), {
          handCount: newCards.length,
          netZero: false
        });
      });
    } catch (e) {
      console.error(e);
      setError(e.message || "카드를 뽑지 못했어요.");
    }
  }

  async function callNetZero() {
    await updateDoc(doc(db, "rooms", roomCode, "players", uid), { netZero: true });
  }

  const cardsPlayedTotal = room.discardPile ? room.discardPile.length : 0;

  if (room.status === "finished" && room.winnerUid) {
    const winner = players.find((p) => p.uid === room.winnerUid);
    return (
      <WinScreen
        winnerName={winner?.name || "플레이어"}
        isMe={room.winnerUid === uid}
        cardsPlayed={cardsPlayedTotal}
        onLeave={onLeave}
      />
    );
  }

  return (
    <div className="gameroom">
      <header className="gameroom-header">
        <div>
          <strong>초대 코드: {roomCode}</strong>
          <span className="muted"> ({orderedPlayers.length}/{MAX_PLAYERS}명)</span>
        </div>
        <button className="link" onClick={onLeave}>
          나가기
        </button>
      </header>

      {error && <p className="error">{error}</p>}

      <div className="player-strip">
        {orderedPlayers.map((p) => (
          <div
            key={p.uid}
            className={`player-chip ${room.currentTurnUid === p.uid ? "active" : ""}`}
          >
            <span>{p.name}{p.uid === room.hostUid ? " 👑" : ""}</span>
            <span className="hand-count">🂠 {p.handCount ?? 0}</span>
            {p.netZero && p.handCount === 1 && <span className="netzero-badge">넷제로!</span>}
          </div>
        ))}
      </div>

      {room.status === "waiting" && (
        <div className="waiting-panel">
          <p>플레이어를 기다리는 중이에요. 친구에게 초대 코드 <b>{roomCode}</b>를 공유해주세요.</p>
          {me?.isHost ? (
            <button className="primary" onClick={startGame}>
              게임 시작 ({orderedPlayers.length}명)
            </button>
          ) : (
            <p className="muted">방장이 게임을 시작할 때까지 기다려주세요.</p>
          )}
        </div>
      )}

      {room.status === "playing" && (
        <>
          <div className="table">
            <div className="discard-area">
              <p className="muted">현재 색상</p>
              <div
                className="color-indicator"
                style={{ background: COLOR_HEX[room.currentColor] }}
              >
                {COLOR_LABEL[room.currentColor] || room.currentColor}
              </div>
              {topCard && <Card card={topCard} disabled />}
            </div>
            <div className="deck-area">
              <p className="muted">남은 카드: {room.deck?.length ?? 0}</p>
              <button
                className="secondary"
                disabled={!isMyTurn}
                onClick={handleDraw}
              >
                카드 뽑기
              </button>
            </div>
          </div>

          <div className="turn-indicator">
            {isMyTurn ? (
              <p className="my-turn">🌿 당신의 차례예요!</p>
            ) : (
              <p className="muted">
                {players.find((p) => p.uid === room.currentTurnUid)?.name || "상대"}님의 차례
              </p>
            )}
          </div>

          {myHand.length === 1 && !me?.netZero && (
            <button className="netzero-btn" onClick={callNetZero}>
              🚨 넷제로! 외치기
            </button>
          )}

          <div className="my-hand">
            {myHand.map((card) => (
              <Card
                key={card.id}
                card={card}
                disabled={!isMyTurn || !canPlay(card, topCard, room.currentColor)}
                onClick={handlePlay}
              />
            ))}
          </div>
        </>
      )}

      {pendingWild && (
        <div className="modal-backdrop">
          <div className="modal">
            <h3>색상을 선택하세요</h3>
            <div className="color-picker">
              {COLORS.map((c) => (
                <button
                  key={c}
                  className="color-choice"
                  style={{ background: COLOR_HEX[c] }}
                  onClick={() => doPlay(pendingWild, c)}
                >
                  {COLOR_LABEL[c]}
                </button>
              ))}
            </div>
            <button className="link" onClick={() => setPendingWild(null)}>
              취소
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
