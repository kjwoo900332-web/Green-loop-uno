import React from "react";
import { calcCO2SavedGrams } from "../gameLogic";

export default function WinScreen({ winnerName, isMe, cardsPlayed, onLeave }) {
  const co2g = calcCO2SavedGrams(cardsPlayed);
  const co2kg = (co2g / 1000).toFixed(2);

  return (
    <div className="winscreen">
      <div className="winscreen-card">
        <h2>{isMe ? "🎉 넷제로 달성! 승리했어요!" : `🏆 ${winnerName}님 승리!`}</h2>
        <p className="co2-headline">이번 게임에서 절감한 CO₂</p>
        <p className="co2-amount">
          {co2g.toLocaleString()} g
          <span className="co2-sub"> ({co2kg} kg)</span>
        </p>
        <p className="co2-desc">
          재생지로 만든 카드 {cardsPlayed}장을 사용해 종이 폐기물 재활용 효과를
          거뒀어요. Green Loop와 함께 순환의 고리를 이어가주셔서 감사합니다 🌱
        </p>
        <button className="primary" onClick={onLeave}>
          로비로 돌아가기
        </button>
      </div>
    </div>
  );
}
